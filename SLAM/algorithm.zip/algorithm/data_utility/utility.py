import numpy as np
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from scipy.optimize import minimize
from math import *
import imageio
import re
import os
import shutil
import seaborn as sns
import copy